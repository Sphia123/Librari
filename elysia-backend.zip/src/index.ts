import { Elysia } from 'elysia';
import { PrismaClient } from '@prisma/client';
import cors from '@elysiajs/cors';

const prisma = new PrismaClient();

const app = new Elysia()
  .use(cors())
  .get('/api/reviews', async () => {
    return prisma.review.findMany();
  })
  .get('/api/reviews/:id', async ({ params }) => {
    return prisma.review.findUnique({
      where: { id: Number(params.id) },
    });
  })
  .post('/api/reviews', async ({ body }) => {
    const { content, rating } = body as { content: string; rating: number };
    return prisma.review.create({
      data: { content, rating },
    });
  })
  .delete('/api/reviews/:id', async ({ params }) => {
    return prisma.review.delete({
      where: { id: Number(params.id) },
    });
  })
  .listen(3000);

console.log('🦊 Elysia is running at http://localhost:3000');
